import {
  AutoAwesomeRounded,
  FactoryRounded,
  Inventory2Rounded,
  LocalShippingRounded,
  ShoppingBagRounded
} from "@mui/icons-material";
import { aiInsights, kpis, orders, stockTrend } from "../data/demoData";
import { Metric, PageHeader, Panel, Pill, ProgressBar, TextLink } from "../components/UI";
import ComponentPhoto from "../components/ComponentPhoto";

export default function Dashboard() {
  const points = stockTrend.map((v, i) => `${i * (100 / (stockTrend.length - 1))},${88 - ((v - 55) / 60) * 68}`).join(" ");

  return (
    <>
      <PageHeader
        title="Supply chain control"
        subtitle="Live operational picture across EV materials, suppliers and inbound logistics."
        action={<button className="btn primary">+ Create purchase order</button>}
      />

      <div className="metric-grid">
        {kpis.map((k, i) => (
          <Metric
            key={k.label}
            {...k}
            icon={[<ShoppingBagRounded />, <Inventory2Rounded />, <FactoryRounded />, <AutoAwesomeRounded />][i]}
          />
        ))}
      </div>

      <div className="dashboard-grid">
        <Panel
          className="span-2"
          title="Inventory value & movement"
          subtitle="12-week stock position across all EV components"
          action={<button className="segment-control"><span className="active">12W</span><span>6M</span><span>1Y</span></button>}
        >
          <div className="chart-summary">
            <div><span>Current on-hand value</span><strong>₹8.42 Cr</strong></div>
            <div><span>Change</span><b>+8.8%</b></div>
          </div>
          <div className="line-chart">
            <svg viewBox="0 0 100 100" preserveAspectRatio="none">
              {[20,40,60,80].map(y => <line key={y} x1="0" y1={y} x2="100" y2={y} className="grid-line" />)}
              <polygon points={`0,92 ${points} 100,92`} className="chart-area" />
              <polyline points={points} className="chart-line" />
            </svg>
            <div className="chart-axis">
              <span>Jul</span><span>Aug</span><span>Sep</span><span>Oct</span>
            </div>
          </div>
        </Panel>

        <Panel title="Network health" subtitle="Current operational distribution">
          <div className="health-ring-wrap">
            <div className="health-ring"><div><strong>92%</strong><span>Healthy</span></div></div>
          </div>
          <div className="health-list">
            <Health label="Inventory" value="95%" tone="good" />
            <Health label="Suppliers" value="89%" tone="good" />
            <Health label="Inbound logistics" value="84%" tone="warn" />
            <Health label="AI risk posture" value="91%" tone="good" />
          </div>
        </Panel>

        <Panel className="span-2" title="Latest purchase orders" subtitle="Current procurement execution" action={<TextLink>View all</TextLink>}>
          <div className="data-table">
            <div className="table-head">
              <span>Order</span><span>Supplier</span><span>Value</span><span>Progress</span><span>Status</span><span>ETA</span>
            </div>
            {orders.map(order => (
              <div className="table-row" key={order.id}>
                <span className="component-cell compact">
                  <ComponentPhoto name={order.component} size={34} />
                  <span>
                    <b>{order.id}</b>
                    <small>{order.component}</small>
                  </span>
                </span>
                <span>{order.supplier}</span>
                <span>{order.value}</span>
                <span><ProgressBar value={order.progress} /><small>{order.progress}%</small></span>
                <span><Pill tone={order.status === "Delivered" ? "success" : order.status === "Processing" ? "neutral" : "info"}>{order.status}</Pill></span>
                <span>{order.eta}</span>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="AI attention" subtitle="Priority signals for today" action={<AutoAwesomeRounded className="accent-icon" />}>
          <div className="insight-list">
            {aiInsights.map((x, i) => (
              <div className="insight-item" key={x.title}>
                <span className="insight-number">0{i + 1}</span>
                <div>
                  <b>{x.title}</b>
                  <p>{x.text}</p>
                  <button>{x.action} ↗</button>
                </div>
              </div>
            ))}
          </div>
        </Panel>

        <Panel className="span-3 route-panel" title="Inbound movement" subtitle="Active material lanes into Chennai manufacturing hub">
          <div className="route-visual">
            <div className="route-map">
              <span className="hub pune">Pune<i /></span>
              <span className="hub gurugram">Gurugram<i /></span>
              <span className="hub bengaluru">Bengaluru<i /></span>
              <span className="hub coimbatore">Coimbatore<i /></span>
              <span className="hub chennai">Chennai<i /></span>
              <svg viewBox="0 0 100 50" preserveAspectRatio="none">
                <path d="M30 17 C48 20, 50 30, 66 36" />
                <path d="M42 8 C54 13, 57 25, 66 36" />
                <path d="M51 34 C56 34, 61 35, 66 36" />
                <path d="M57 41 C60 40, 62 38, 66 36" />
              </svg>
            </div>
            <div className="route-stats">
              <div><LocalShippingRounded /><span>Active shipments</span><strong>18</strong></div>
              <div><span>On schedule</span><strong>15</strong></div>
              <div><span>Delayed</span><strong>3</strong></div>
              <div><span>Avg ETA confidence</span><strong>94%</strong></div>
            </div>
          </div>
        </Panel>
      </div>
    </>
  );
}

function Health({ label, value, tone }) {
  return <div className="health-row"><span><i className={tone} />{label}</span><b>{value}</b></div>;
}