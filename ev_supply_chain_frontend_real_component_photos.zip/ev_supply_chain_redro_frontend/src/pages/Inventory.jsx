import { FilterAltRounded, Inventory2Rounded, SearchRounded } from "@mui/icons-material";
import { inventory } from "../data/demoData";
import { Metric, PageHeader, Panel, Pill, ProgressBar } from "../components/UI";
import ComponentPhoto from "../components/ComponentPhoto";

export default function Inventory() {
  const healthy = inventory.filter(x => x.status === "Healthy").length;
  const reorder = inventory.filter(x => x.status === "Reorder").length;
  const critical = inventory.filter(x => x.status === "Critical").length;

  return (
    <>
      <PageHeader
        title="Inventory"
        subtitle="Monitor component stock, safety levels and production coverage."
        action={<button className="btn primary">+ Add inventory</button>}
      />

      <div className="metric-grid metric-grid-4">
        <Metric label="Tracked components" value="45" delta="+3 this month" icon={<Inventory2Rounded />} />
        <Metric label="Healthy positions" value={`${healthy + 31}`} delta="82.2% of inventory" tone="good" />
        <Metric label="Reorder required" value={`${reorder + 5}`} delta="7 need action" tone="warn" />
        <Metric label="Critical positions" value={`${critical + 1}`} delta="2 production risks" tone="bad" />
      </div>

      <Panel>
        <div className="toolbar">
          <div className="inline-search"><SearchRounded /><input placeholder="Search component or code..." /></div>
          <button className="filter-btn"><FilterAltRounded /> Category</button>
          <button className="filter-btn"><FilterAltRounded /> Status</button>
          <button className="filter-btn"><FilterAltRounded /> Warehouse</button>
        </div>

        <div className="data-table inventory-table">
          <div className="table-head">
            <span>Component</span><span>Category</span><span>On hand</span><span>Stock position</span><span>Coverage</span><span>Status</span>
          </div>
          {inventory.map(item => {
            const ratio = Math.min(100, Math.round((item.onHand / Math.max(item.reorder * 2, 1)) * 100));
            return (
              <div className="table-row" key={item.code}>
                <span className="component-cell">
                  <ComponentPhoto name={item.component} />
                  <span>
                    <b>{item.component}</b>
                    <small>{item.code}</small>
                  </span>
                </span>
                <span>{item.category}</span>
                <span><b>{item.onHand.toLocaleString("en-IN")}</b><small>Safety {item.safety.toLocaleString("en-IN")}</small></span>
                <span><ProgressBar value={ratio} tone={item.status === "Critical" ? "red" : item.status === "Reorder" ? "amber" : "teal"} /><small>Reorder at {item.reorder.toLocaleString("en-IN")}</small></span>
                <span>{item.coverage}</span>
                <span><Pill tone={item.status === "Healthy" ? "success" : item.status === "Reorder" ? "warning" : "danger"}>{item.status}</Pill></span>
              </div>
            );
          })}
        </div>
      </Panel>
    </>
  );
}