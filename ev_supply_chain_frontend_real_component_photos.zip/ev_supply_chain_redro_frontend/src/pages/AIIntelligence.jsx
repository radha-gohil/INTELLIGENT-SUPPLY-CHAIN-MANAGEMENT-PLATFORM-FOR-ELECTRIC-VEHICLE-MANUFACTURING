import { AutoAwesomeRounded, BoltRounded, PsychologyRounded } from "@mui/icons-material";
import { aiInsights } from "../data/demoData";
import { Metric, PageHeader, Panel, Pill } from "../components/UI";

export default function AIIntelligence() {
  return (
    <>
      <PageHeader
        title="AI intelligence"
        subtitle="Predictive signals and decision support across your EV supply network."
        action={<button className="btn primary"><AutoAwesomeRounded /> Ask EVFlow AI</button>}
      />

      <div className="metric-grid metric-grid-4">
        <Metric label="Signals analyzed" value="12,840" delta="Last 24 hours" icon={<PsychologyRounded />} />
        <Metric label="Predicted risks" value="12" delta="3 high priority" tone="warn" />
        <Metric label="Actions suggested" value="21" delta="9 accepted" tone="good" />
        <Metric label="Decision confidence" value="91.8%" delta="+4.2%" tone="good" />
      </div>

      <div className="ai-layout">
        <Panel className="ai-primary" title="What needs attention" subtitle="Ranked by production impact and decision confidence">
          <div className="ai-cards">
            {aiInsights.map((x, i) => (
              <article className="ai-card" key={x.title}>
                <div className="ai-card-index">0{i+1}</div>
                <div className="ai-card-body">
                  <div className="ai-card-title">
                    <h3>{x.title}</h3>
                    <Pill tone={x.severity === "High" ? "danger" : x.severity === "Medium" ? "warning" : "success"}>{x.severity}</Pill>
                  </div>
                  <p>{x.text}</p>
                  <div className="ai-reason">
                    <BoltRounded />
                    <span>
                      <b>Why this matters</b>
                      Production continuity and supplier timing are both contributing to this score.
                    </span>
                  </div>
                  <button className="btn ghost">{x.action}</button>
                </div>
              </article>
            ))}
          </div>
        </Panel>

        <Panel title="AI assistant" subtitle="Prototype conversational planning">
          <div className="assistant-card">
            <div className="assistant-orb"><AutoAwesomeRounded /></div>
            <h3>How can I help?</h3>
            <p>Ask about inventory risk, supplier options, procurement priorities or shipment delays.</p>
            <div className="prompt-chips">
              <button>What can delay production?</button>
              <button>Which supplier is safest?</button>
              <button>What should we reorder?</button>
            </div>
            <div className="assistant-input"><input placeholder="Ask EVFlow AI..." /><button>→</button></div>
          </div>
        </Panel>
      </div>
    </>
  );
}