import { LocalShippingRounded } from "@mui/icons-material";
import { shipments } from "../data/demoData";
import { Metric, PageHeader, Panel, Pill, ProgressBar } from "../components/UI";

export default function Shipments() {
  return (
    <>
      <PageHeader
        title="Shipments"
        subtitle="Track inbound material movement, ETA confidence and logistics exceptions."
        action={<button className="btn primary">+ Simulate shipment</button>}
      />

      <div className="metric-grid metric-grid-4">
        <Metric label="Active shipments" value="18" delta="+3 today" icon={<LocalShippingRounded />} />
        <Metric label="On schedule" value="15" delta="83.3% lanes" tone="good" />
        <Metric label="Delayed" value="3" delta="1 production linked" tone="warn" />
        <Metric label="ETA confidence" value="94%" delta="+2.4%" tone="good" />
      </div>

      <div className="dashboard-grid">
        <Panel className="span-2" title="Active inbound movement" subtitle="Live shipment execution">
          <div className="shipment-list">
            {shipments.map(s => (
              <div className="shipment-card" key={s.id}>
                <div className="shipment-icon"><LocalShippingRounded /></div>
                <div className="shipment-main">
                  <div className="shipment-title"><b>{s.route}</b><span>{s.id} • {s.carrier}</span></div>
                  <div className="shipment-load">{s.load}</div>
                  <ProgressBar value={s.progress} tone={s.status.includes("Delayed") ? "amber" : "teal"} />
                </div>
                <div className="shipment-end">
                  <Pill tone={s.status.includes("Delayed") ? "warning" : "success"}>{s.status}</Pill>
                  <span>{s.eta}</span>
                </div>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Lane performance" subtitle="Last 30 days">
          <div className="lane-list">
            <Lane route="Pune → Chennai" rate="96%" time="18h 20m" />
            <Lane route="Bengaluru → Chennai" rate="94%" time="7h 45m" />
            <Lane route="Gurugram → Chennai" rate="81%" time="42h 10m" />
            <Lane route="Coimbatore → Chennai" rate="97%" time="8h 05m" />
          </div>
        </Panel>
      </div>
    </>
  );
}

function Lane({ route, rate, time }) {
  return <div className="lane"><div><b>{route}</b><span>Avg transit {time}</span></div><strong>{rate}</strong></div>;
}