import {
  ArrowForwardRounded,
  AutoAwesomeRounded,
  CheckCircleRounded,
  FactoryRounded,
  Inventory2Rounded,
  LocalShippingRounded,
  DarkModeRounded,
  LightModeRounded
} from "@mui/icons-material";
import { Link } from "react-router-dom";
import Brand from "../components/Brand";
import { kpis, orders } from "../data/demoData";
import { ProgressBar } from "../components/UI";
import ComponentPhoto from "../components/ComponentPhoto";
import { useThemeMode } from "../ThemeContext";

const partnerNames = ["VoltEdge", "MobiEV", "Axion", "NeoDrive", "FluxLabs"];

export default function Home() {
  const { isDark, toggleTheme } = useThemeMode();

  return (
    <div className="marketing-page">
      <div className="hero-grid-lines" />

      <header className="marketing-nav">
        <Brand />
        <nav>
          <a href="#platform">Platform</a>
          <a href="#network">Network</a>
          <a href="#intelligence">Intelligence</a>
          <a href="#about">About</a>
        </nav>
        <div className="nav-actions">
          <button
            className="theme-switch"
            onClick={toggleTheme}
            aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
            title={isDark ? "Light theme" : "Dark theme"}
          >
            {isDark ? <LightModeRounded /> : <DarkModeRounded />}
            <span>{isDark ? "Light" : "Dark"}</span>
          </button>
          <button className="btn ghost">Sign in</button>
          <Link className="btn primary" to="/app/dashboard">Open platform</Link>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-flow-line left" />
          <div className="hero-flow-line right" />

          <div className="hero-kicker">
            <span className="live-dot" />
            Intelligent EV supply chain
            <ArrowForwardRounded />
          </div>

          <h1>
            Supply Chain
            <span> Intelligence</span>
          </h1>

          <p>
            One connected workspace for EV inventory, suppliers, procurement,
            logistics and AI-driven risk decisions.
          </p>

          <div className="hero-actions">
            <Link className="btn primary large" to="/app/dashboard">
              Get started
              <ArrowForwardRounded />
            </Link>
            <a className="btn ghost large" href="#platform">Explore platform</a>
          </div>

          <div className="product-window" id="platform">
            <div className="window-top">
              <div className="window-brand"><Brand compact /></div>
              <div className="window-search">Search anything...</div>
              <div className="window-user">RG</div>
            </div>

            <div className="window-body">
              <aside className="window-side">
                <span className="active"><i /><em>Overview</em></span>
                <span><i /><em>Inventory</em></span>
                <span><i /><em>Suppliers</em></span>
                <span><i /><em>Orders</em></span>
                <span><i /><em>Shipments</em></span>
              </aside>

              <div className="window-content">
                <div className="mock-welcome">
                  <div>
                    <small>Good afternoon</small>
                    <h3>Welcome back, Radha</h3>
                    <p>Track materials, suppliers and EV production readiness.</p>
                  </div>
                  <button className="mini-primary">+ Create order</button>
                </div>

                <div className="mock-metrics">
                  {kpis.map(kpi => (
                    <div className="mock-metric" key={kpi.label}>
                      <small>{kpi.label}</small>
                      <b>{kpi.value}</b>
                      <span>{kpi.delta}</span>
                    </div>
                  ))}
                  <div className="mock-highlight">
                    <small>AI network health</small>
                    <b>92%</b>
                    <p>Stable across 27 suppliers</p>
                  </div>
                </div>

                <div className="mock-lower">
                  <div className="mock-table">
                    <div className="mock-section-title">
                      <div>
                        <b>Latest orders</b>
                        <span>Live procurement movement</span>
                      </div>
                      <span>View all ↗</span>
                    </div>

                    {orders.slice(0, 4).map(order => (
                      <div className="mock-row" key={order.id}>
                        <div className="mock-order-component">
                          <ComponentPhoto name={order.component} size={27} rounded={5} />
                          <span>
                            <b>{order.id}</b>
                            <span>{order.component}</span>
                          </span>
                        </div>
                        <div><b>{order.value}</b><span>{order.supplier}</span></div>
                        <div>
                          <ProgressBar value={order.progress} />
                          <span>{order.progress}%</span>
                        </div>
                        <div className="mock-status">{order.status}</div>
                      </div>
                    ))}
                  </div>

                  <div className="mock-chart">
                    <div className="mock-section-title">
                      <div><b>Item traffic</b><span>Last 7 days</span></div>
                    </div>
                    <div className="bars">
                      {[38, 54, 62, 48, 82, 68, 91].map((x, i) => <i key={i} style={{height: `${x}%`}} />)}
                    </div>
                    <div className="chart-labels">
                      <span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span><span>S</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="partner-strip">
            <span>Trusted supply ecosystem</span>
            {partnerNames.map(x => <b key={x}>{x}</b>)}
          </div>
        </section>

        <section className="feature-section" id="network">
          <div className="section-copy">
            <span className="section-index">01 / CONTROL</span>
            <h2>See every movement across your EV supply chain.</h2>
            <p>
              Keep component availability, supplier readiness, purchase orders and
              inbound logistics in one operational view.
            </p>
          </div>

          <div className="feature-grid">
            <FeatureCard
              icon={<Inventory2Rounded />}
              label="Inventory control"
              title="Material health without spreadsheet blind spots."
              copy="Track safety stock, reorder points, coverage days and production-critical components."
            />
            <FeatureCard
              icon={<FactoryRounded />}
              label="Supplier network"
              title="Know who can deliver before you place the order."
              copy="Compare reliability, fulfillment, quality and AI risk across every supplier."
            />
            <FeatureCard
              icon={<LocalShippingRounded />}
              label="Inbound logistics"
              title="Watch purchase orders turn into real arrivals."
              copy="Track shipment stages, ETA drift and route exceptions in a single view."
            />
            <FeatureCard
              icon={<AutoAwesomeRounded />}
              label="AI decisions"
              title="Surface risks before they become production delays."
              copy="Use predictive signals to prioritize shortages, supplier drift and shipment exceptions."
            />
          </div>
        </section>

        <section className="intelligence-band" id="intelligence">
          <div className="intelligence-copy">
            <span className="section-index light">02 / INTELLIGENCE</span>
            <h2>AI that tells you what deserves attention next.</h2>
            <p>
              EVFlow turns operational data into prioritized actions instead of adding another dashboard to monitor.
            </p>
            <Link className="btn light" to="/app/ai">Open AI intelligence <ArrowForwardRounded /></Link>
          </div>

          <div className="ai-preview">
            <div className="ai-preview-head">
              <span><AutoAwesomeRounded /> EVFlow AI</span>
              <em>Live</em>
            </div>
            <div className="ai-alert">
              <span className="alert-index">01</span>
              <div>
                <b>Motor Controller shortage risk</b>
                <p>Inventory may cross safety stock in 4.2 days based on current production demand.</p>
              </div>
              <button>Review</button>
            </div>
            <div className="ai-alert">
              <span className="alert-index">02</span>
              <div>
                <b>Supplier lead-time drift</b>
                <p>Power Electronics India is trending 1.8 days behind committed lead time.</p>
              </div>
              <button>Review</button>
            </div>
            <div className="ai-checks">
              <span><CheckCircleRounded /> Inventory synchronized</span>
              <span><CheckCircleRounded /> Supplier signals updated</span>
              <span><CheckCircleRounded /> Logistics ETA refreshed</span>
            </div>
          </div>
        </section>

        <footer className="marketing-footer" id="about">
          <Brand />
          <p>Intelligent supply chain management for electric vehicle manufacturing.</p>
          <span>Prototype interface • 2026</span>
        </footer>
      </main>
    </div>
  );
}

function FeatureCard({ icon, label, title, copy }) {
  return (
    <article className="feature-card">
      <div className="feature-icon">{icon}</div>
      <small>{label}</small>
      <h3>{title}</h3>
      <p>{copy}</p>
      <button>Explore <ArrowForwardRounded /></button>
    </article>
  );
}