import { ShoppingCartRounded } from "@mui/icons-material";
import { orders } from "../data/demoData";
import { Metric, PageHeader, Panel, Pill, ProgressBar } from "../components/UI";
import ComponentPhoto from "../components/ComponentPhoto";

export default function Procurement() {
  return (
    <>
      <PageHeader
        title="Procurement"
        subtitle="Manage purchase orders from requirement through supplier fulfillment."
        action={<button className="btn primary">+ New purchase order</button>}
      />

      <div className="metric-grid metric-grid-4">
        <Metric label="Open purchase orders" value="38" delta="+5 this week" icon={<ShoppingCartRounded />} />
        <Metric label="Open value" value="₹4.82 Cr" delta="+6.4%" />
        <Metric label="On-time fulfillment" value="92.6%" delta="+3.1%" tone="good" />
        <Metric label="Orders at risk" value="5" delta="2 high priority" tone="warn" />
      </div>

      <div className="dashboard-grid procurement-grid">
        <Panel className="span-2" title="Purchase orders" subtitle="Recent and active procurement commitments">
          <div className="data-table">
            <div className="table-head">
              <span>Order</span><span>Supplier</span><span>Value</span><span>Progress</span><span>Status</span><span>ETA</span>
            </div>
            {[...orders, ...orders.slice(0,2).map((x, i) => ({...x, id:`PO-201${i+7}`}))].map(order => (
              <div className="table-row" key={order.id}>
                <span className="component-cell compact">
                  <ComponentPhoto name={order.component} size={34} />
                  <span>
                    <b>{order.id}</b>
                    <small>{order.component}</small>
                  </span>
                </span>
                <span>{order.supplier}</span>
                <span>{order.value}</span>
                <span><ProgressBar value={order.progress} /><small>{order.progress}%</small></span>
                <span><Pill tone={order.status === "Delivered" ? "success" : order.status === "Processing" ? "neutral" : "info"}>{order.status}</Pill></span>
                <span>{order.eta}</span>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Spend distribution" subtitle="Current month">
          <div className="donut-wrap">
            <div className="donut"><div><strong>₹2.18Cr</strong><span>Total</span></div></div>
          </div>
          <div className="legend-list">
            <span><i className="c1" /> Battery systems <b>42%</b></span>
            <span><i className="c2" /> Electronics <b>26%</b></span>
            <span><i className="c3" /> Mechanical <b>18%</b></span>
            <span><i className="c4" /> Other <b>14%</b></span>
          </div>
        </Panel>
      </div>
    </>
  );
}