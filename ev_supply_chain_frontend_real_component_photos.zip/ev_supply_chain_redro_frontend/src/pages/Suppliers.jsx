import { FactoryRounded, FilterAltRounded, SearchRounded } from "@mui/icons-material";
import { suppliers } from "../data/demoData";
import { Metric, PageHeader, Panel, Pill, ProgressBar } from "../components/UI";

export default function Suppliers() {
  return (
    <>
      <PageHeader
        title="Suppliers"
        subtitle="Compare performance, reliability, quality and supply risk."
        action={<button className="btn primary">+ Add supplier</button>}
      />

      <div className="metric-grid metric-grid-4">
        <Metric label="Active suppliers" value="27" delta="+2 this quarter" icon={<FactoryRounded />} />
        <Metric label="Average reliability" value="74.8%" delta="+1.6%" />
        <Metric label="Low-risk suppliers" value="21" delta="77.8% network" tone="good" />
        <Metric label="Needs attention" value="6" delta="4 medium • 2 high" tone="warn" />
      </div>

      <Panel>
        <div className="toolbar">
          <div className="inline-search"><SearchRounded /><input placeholder="Search supplier..." /></div>
          <button className="filter-btn"><FilterAltRounded /> Component</button>
          <button className="filter-btn"><FilterAltRounded /> Risk</button>
        </div>

        <div className="supplier-cards">
          {suppliers.map((s, i) => (
            <article className="supplier-card" key={s.id}>
              <div className="supplier-card-top">
                <div className="supplier-logo">{s.name.split(" ").slice(0,2).map(x => x[0]).join("")}</div>
                <div><h3>{s.name}</h3><span>{s.id} • {s.parts} supplied components</span></div>
                <Pill tone={s.risk === "Low" ? "success" : "warning"}>{s.risk} risk</Pill>
              </div>

              <div className="supplier-score">
                <div><span>Reliability</span><strong>{s.reliability.toFixed(1)}%</strong></div>
                <ProgressBar value={s.reliability} />
              </div>

              <div className="supplier-stats">
                <div><span>Quality</span><b>{s.quality}%</b></div>
                <div><span>Fulfillment</span><b>{s.fulfillment.toFixed(1)}%</b></div>
                <div><span>Lead time</span><b>{s.lead} days</b></div>
              </div>

              <button className="card-link">View supplier <span>↗</span></button>
            </article>
          ))}
        </div>
      </Panel>
    </>
  );
}