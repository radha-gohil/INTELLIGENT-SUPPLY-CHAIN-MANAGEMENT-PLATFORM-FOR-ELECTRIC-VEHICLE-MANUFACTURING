import { Navigate, Route, Routes } from "react-router-dom";
import AppShell from "./components/AppShell";
import Dashboard from "./pages/Dashboard";
import Inventory from "./pages/Inventory";
import Suppliers from "./pages/Suppliers";
import Procurement from "./pages/Procurement";
import Shipments from "./pages/Shipments";
import AIIntelligence from "./pages/AIIntelligence";
import Home from "./pages/Home";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />

      <Route element={<AppShell />}>
        <Route path="/app/dashboard" element={<Dashboard />} />
        <Route path="/app/inventory" element={<Inventory />} />
        <Route path="/app/suppliers" element={<Suppliers />} />
        <Route path="/app/procurement" element={<Procurement />} />
        <Route path="/app/shipments" element={<Shipments />} />
        <Route path="/app/ai" element={<AIIntelligence />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}