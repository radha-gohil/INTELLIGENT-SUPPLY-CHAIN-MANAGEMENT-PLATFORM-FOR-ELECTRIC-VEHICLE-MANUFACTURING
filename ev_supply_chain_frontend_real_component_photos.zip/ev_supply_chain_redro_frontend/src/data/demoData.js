export const componentPhotos = {
  "Lithium Battery Pack":
    "https://images.newswitch.jp/images/gBsbjTrMk8v3kIf4WpKf8PajGv7D4lewOvrkaf90.jpeg",

  "Battery Pack":
    "https://images.newswitch.jp/images/gBsbjTrMk8v3kIf4WpKf8PajGv7D4lewOvrkaf90.jpeg",

  "Traction Motor":
    "https://mnd-assets.mynewsdesk.com/image/upload/f_auto,t_limit_1000/crfijxpe3ikdwks6v4vy.jpg",

  "Motor Controller":
    "https://sc04.alicdn.com/kf/HTB1MxZ5ba5s3KVjSZFNq6AD3FXaB.jpg",

  "DC-DC Converter":
    "https://www.bosch-mobility.com/media/global/general/360-degree/pc-hochvolthybrid-dcdc-wandler/22.png",

  "Brake Assembly":
    "https://images.pistonheads.com/nimg/37842/phdisc-003.jpg",

  "Thermal Cooling Unit":
    "https://mma.prnewswire.com/media/2946658/Hanon_Systems_HICE_product_image.jpg?p=twitter",

  "Inverter Module":
    "https://img1.firmenauto.de/Bosch-Wechseltrichter-2025-jsonLd4x3-b9b1df3-392225.jpg",

  "Gear Set":
    "https://cdn.lincos.io/images/48469.jpg",

  "Chassis Frame":
    "https://geelysakartvelo.com/storage/1867/GEA-platform.jpg"
};

export function getComponentPhoto(componentName) {
  return componentPhotos[componentName] || componentPhotos["Lithium Battery Pack"];
}

export const kpis = [
  { label: "Today orders", value: "1,352", delta: "+11.4%", tone: "up" },
  { label: "Procurement value", value: "₹13.28 Cr", delta: "+8.2%", tone: "up" },
  { label: "Avg supplier score", value: "91.4%", delta: "+2.7%", tone: "up" },
  { label: "At-risk parts", value: "12", delta: "-18.6%", tone: "good" }
];

export const orders = [
  { id: "PO-2048", supplier: "Battery Systems India", component: "Battery Pack", qty: 180, value: "₹27.0L", status: "In transit", progress: 72, eta: "08 Oct" },
  { id: "PO-2043", supplier: "Power Electronics India", component: "Inverter Module", qty: 320, value: "₹18.4L", status: "Processing", progress: 44, eta: "10 Oct" },
  { id: "PO-2038", supplier: "EV Control Technologies", component: "Motor Controller", qty: 240, value: "₹15.6L", status: "Delivered", progress: 100, eta: "Delivered" },
  { id: "PO-2034", supplier: "Automotive Mechanical Systems", component: "Gear Set", qty: 410, value: "₹12.9L", status: "In transit", progress: 63, eta: "09 Oct" },
  { id: "PO-2029", supplier: "Vehicle Structure Systems", component: "Chassis Frame", qty: 75, value: "₹21.7L", status: "Processing", progress: 28, eta: "12 Oct" }
];

export const stockTrend = [66, 70, 58, 78, 74, 86, 92, 88, 97, 101, 96, 112];

export const inventory = [
  { code: "CMP-001", component: "Lithium Battery Pack", category: "Battery", onHand: 7900, safety: 2200, reorder: 3000, coverage: "18 days", status: "Healthy" },
  { code: "CMP-008", component: "Traction Motor", category: "Powertrain", onHand: 3280, safety: 1800, reorder: 2200, coverage: "13 days", status: "Healthy" },
  { code: "CMP-012", component: "Motor Controller", category: "Electronics", onHand: 1120, safety: 900, reorder: 1500, coverage: "6 days", status: "Reorder" },
  { code: "CMP-019", component: "DC-DC Converter", category: "Electronics", onHand: 610, safety: 500, reorder: 900, coverage: "4 days", status: "Critical" },
  { code: "CMP-027", component: "Brake Assembly", category: "Mechanical", onHand: 2480, safety: 1200, reorder: 1700, coverage: "15 days", status: "Healthy" },
  { code: "CMP-031", component: "Thermal Cooling Unit", category: "Thermal", onHand: 890, safety: 700, reorder: 1100, coverage: "7 days", status: "Reorder" }
];

export const suppliers = [
  { name: "Automotive Mechanical Systems", id: "S027", reliability: 87, quality: 94, fulfillment: 97, lead: 12, risk: "Low", parts: 5 },
  { name: "EV Control Technologies", id: "S022", reliability: 73.46, quality: 91, fulfillment: 98.19, lead: 15, risk: "Low", parts: 4 },
  { name: "Battery Systems India", id: "S001", reliability: 70.22, quality: 90, fulfillment: 96.34, lead: 16, risk: "Low", parts: 7 },
  { name: "Power Electronics India", id: "S008", reliability: 69.68, quality: 88, fulfillment: 95.8, lead: 14, risk: "Medium", parts: 6 },
  { name: "Vehicle Structure Systems", id: "S026", reliability: 68.4, quality: 92, fulfillment: 95.94, lead: 18, risk: "Medium", parts: 4 }
];

export const shipments = [
  { id: "SHP-8821", route: "Pune → Chennai", carrier: "BlueDart Freight", load: "Battery Packs", status: "On schedule", eta: "Today, 18:40", progress: 78 },
  { id: "SHP-8817", route: "Bengaluru → Chennai", carrier: "Delhivery B2B", load: "Control Units", status: "On schedule", eta: "Tomorrow, 09:10", progress: 61 },
  { id: "SHP-8809", route: "Gurugram → Chennai", carrier: "TCI Express", load: "Chassis Parts", status: "Delayed 6h", eta: "Tomorrow, 14:30", progress: 48 },
  { id: "SHP-8795", route: "Coimbatore → Chennai", carrier: "VRL Logistics", load: "Thermal Units", status: "At hub", eta: "09 Oct, 11:00", progress: 36 }
];

export const aiInsights = [
  {
    title: "Motor Controller shortage risk",
    severity: "High",
    text: "Projected stock falls below safety level in 4.2 days if current production demand continues.",
    action: "Create replenishment PO"
  },
  {
    title: "Supplier lead-time drift",
    severity: "Medium",
    text: "Power Electronics India has averaged +1.8 days against committed lead time across the last four orders.",
    action: "Review supplier"
  },
  {
    title: "Shipment consolidation opportunity",
    severity: "Low",
    text: "Two Bengaluru-origin orders can be consolidated into one lane and reduce estimated freight cost by 12%.",
    action: "View simulation"
  }
];