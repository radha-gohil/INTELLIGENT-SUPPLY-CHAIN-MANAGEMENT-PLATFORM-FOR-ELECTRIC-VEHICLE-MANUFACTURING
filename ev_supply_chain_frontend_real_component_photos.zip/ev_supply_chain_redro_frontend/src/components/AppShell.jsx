import {
  AutoAwesomeRounded,
  DashboardRounded,
  FactoryRounded,
  Inventory2Rounded,
  LocalShippingRounded,
  SearchRounded,
  ShoppingCartRounded,
  DarkModeRounded,
  LightModeRounded
} from "@mui/icons-material";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import Brand from "./Brand";
import { useThemeMode } from "../ThemeContext";

const nav = [
  { label: "Overview", to: "/app/dashboard", icon: <DashboardRounded /> },
  { label: "Inventory", to: "/app/inventory", icon: <Inventory2Rounded /> },
  { label: "Suppliers", to: "/app/suppliers", icon: <FactoryRounded /> },
  { label: "Procurement", to: "/app/procurement", icon: <ShoppingCartRounded /> },
  { label: "Shipments", to: "/app/shipments", icon: <LocalShippingRounded /> },
  { label: "AI intelligence", to: "/app/ai", icon: <AutoAwesomeRounded /> }
];

const pageNames = {
  "/app/dashboard": "Overview",
  "/app/inventory": "Inventory",
  "/app/suppliers": "Suppliers",
  "/app/procurement": "Procurement",
  "/app/shipments": "Shipments",
  "/app/ai": "AI intelligence"
};

export default function AppShell() {
  const location = useLocation();
  const { isDark, toggleTheme } = useThemeMode();

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-logo"><Brand /></div>

        <nav className="sidebar-nav">
          {nav.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `side-link ${isActive ? "active" : ""}`}
            >
              <span className="side-icon">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-foot">
          <div className="mini-health">
            <div className="mini-health-dot" />
            <div>
              <b>Supply network</b>
              <span>All systems operational</span>
            </div>
          </div>
        </div>
      </aside>

      <main className="app-main">
        <header className="topbar">
          <div>
            <div className="eyebrow">EV manufacturing network</div>
            <h1>{pageNames[location.pathname] || "Workspace"}</h1>
          </div>

          <div className="top-actions">
            <label className="search-box">
              <SearchRounded />
              <input placeholder="Search orders, suppliers, parts..." />
              <kbd>⌘ K</kbd>
            </label>

            <button
              className="icon-button theme-toggle"
              onClick={toggleTheme}
              aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
              title={isDark ? "Light theme" : "Dark theme"}
            >
              {isDark ? <LightModeRounded /> : <DarkModeRounded />}
            </button>

            <button className="icon-button">?</button>
            <div className="avatar">RG</div>
          </div>
        </header>

        <section className="page-wrap">
          <Outlet />
        </section>
      </main>
    </div>
  );
}