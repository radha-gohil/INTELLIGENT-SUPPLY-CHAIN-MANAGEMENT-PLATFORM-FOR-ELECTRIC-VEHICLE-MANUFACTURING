import ArrowOutwardRoundedIcon from "@mui/icons-material/ArrowOutwardRounded";

export function Pill({ children, tone = "neutral" }) {
  return <span className={`pill ${tone}`}>{children}</span>;
}

export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="page-header">
      <div>
        <h2>{title}</h2>
        <p>{subtitle}</p>
      </div>
      {action}
    </div>
  );
}

export function Panel({ title, subtitle, action, children, className = "" }) {
  return (
    <section className={`panel ${className}`}>
      {(title || action) && (
        <div className="panel-head">
          <div>
            {title && <h3>{title}</h3>}
            {subtitle && <p>{subtitle}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function Metric({ label, value, delta, tone = "up", icon }) {
  return (
    <div className="metric">
      <div className="metric-top">
        <span>{label}</span>
        {icon && <div className="metric-icon">{icon}</div>}
      </div>
      <div className="metric-value">{value}</div>
      <div className={`metric-delta ${tone}`}>{delta}</div>
    </div>
  );
}

export function TextLink({ children }) {
  return (
    <button className="text-link">
      {children}
      <ArrowOutwardRoundedIcon />
    </button>
  );
}

export function ProgressBar({ value, tone = "teal" }) {
  return (
    <div className={`progress ${tone}`}>
      <span style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}