import { useState } from "react";
import { getComponentPhoto } from "../data/demoData";

export default function ComponentPhoto({
  name,
  size = 42,
  rounded = 7
}) {
  const [failed, setFailed] = useState(false);

  return (
    <div
      className="component-photo"
      style={{
        width: size,
        height: size,
        borderRadius: rounded
      }}
    >
      {!failed ? (
        <img
          src={getComponentPhoto(name)}
          alt={name}
          loading="lazy"
          onError={() => setFailed(true)}
        />
      ) : (
        <div className="component-photo-fallback">
          {name
            .split(" ")
            .slice(0, 2)
            .map(word => word[0])
            .join("")}
        </div>
      )}
    </div>
  );
}