export default function Brand({ compact = false }) {
  return (
    <div className="brand">
      <span className="brand-mark">
        <i />
        <i />
        <i />
      </span>
      {!compact && <span className="brand-name">EVFlow</span>}
    </div>
  );
}